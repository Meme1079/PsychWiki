function onEvent(name, value1, value2)
     if name == 'Opponent Fade' then
          doTweenAlpha('opponent', 'dad', 0, value1, 'linear')
     end
end